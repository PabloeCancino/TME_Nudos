# Guía de Uso: CrossingPairIsomorphism.lean

## 📋 Resumen

`CrossingPairIsomorphism.lean` es un nuevo módulo que establece el **isomorfismo explícito** entre `RationalCrossing 3` (perspectiva topológica) y `OrderedPair` (perspectiva algebraica) en la TME.

```
📁 CrossingPairIsomorphism.lean
📏 Líneas: 519
🎯 Propósito: Formalizar la dualidad topología ↔ álgebra
✅ Estado: Completo y documentado
🔗 Depende: Basic.lean, TCN_01_Fundamentos.lean
```

---

## 🎯 ¿Por Qué Este Módulo?

### Problema Original

El proyecto tiene DOS representaciones del mismo objeto:

```lean
-- Basic.lean (topológico)
structure RationalCrossing 3 where
  over_pos : ZMod 6    -- "arriba"
  under_pos : ZMod 6   -- "abajo"

-- TCN_01 (algebraico)
structure OrderedPair where
  fst : ZMod 6         -- "entrada"
  snd : ZMod 6         -- "salida"
```

### Solución

En lugar de unificar (perdiendo riqueza semántica), **mantenemos ambas** y hacemos el isomorfismo **explícito**:

```lean
crossing_to_pair : RationalCrossing 3 ≃ OrderedPair
```

---

## 🚀 Uso Básico

### 1. Conversiones entre Tipos

```lean
import TMENudos.CrossingPairIsomorphism

-- Crear un cruce topológico
def c : RationalCrossing 3 := ⟨0, 3, by decide⟩

-- Convertir a par algebraico (notación conveniente)
def p : OrderedPair := c⟦⟧ᵃ
-- Resultado: p = ⟨0, 3, ...⟩

-- Convertir de vuelta
def c' : RationalCrossing 3 := p⟦⟧ᵗ
-- Resultado: c' = c (isomorfismo es involutivo)
```

### 2. Notación

| Notación | Significado | Dirección |
|----------|-------------|-----------|
| `c⟦⟧ᵃ` | Crossing to Algebraic | Topológico → Algebraico |
| `p⟦⟧ᵗ` | Pair to Topological | Algebraico → Topológico |

**Mnemotécnico**:
- `ᵃ` = **a**lgebraic
- `ᵗ` = **t**opological

---

## 🔧 Funcionalidades Principales

### A. Isomorfismo Base

```lean
-- Definición explícita del isomorfismo
crossing_to_pair : RationalCrossing 3 ≃ OrderedPair

-- Isomorfismo inverso
pair_to_crossing : OrderedPair ≃ RationalCrossing 3
-- Equivale a: crossing_to_pair.symm
```

### B. Propiedades Preservadas

```lean
-- Preserva primer elemento
theorem iso_preserves_first (c : RationalCrossing 3) :
  (c⟦⟧ᵃ).fst = c.over_pos

-- Preserva segundo elemento
theorem iso_preserves_second (c : RationalCrossing 3) :
  (c⟦⟧ᵃ).snd = c.under_pos

-- Preserva desplazamiento modular
theorem iso_preserves_displacement (c : RationalCrossing 3) :
  modular_ratio c = (c⟦⟧ᵃ).snd - (c⟦⟧ᵃ).fst
```

### C. Involutividad

```lean
-- Ida y vuelta recupera el original
theorem iso_roundtrip_crossing (c : RationalCrossing 3) :
  (c⟦⟧ᵃ)⟦⟧ᵗ = c

theorem iso_roundtrip_pair (p : OrderedPair) :
  (p⟦⟧ᵗ)⟦⟧ᵃ = p
```

---

## ⚡ Transferencia de Teoremas

### Patrón Principal

El poder real del módulo está en **transferir teoremas** automáticamente entre contextos.

### Ejemplo 1: De Algebraico a Topológico

```lean
-- Tenemos un teorema sobre pares
theorem pair_property : ∀ p : OrderedPair, p.fst ≠ p.snd := by
  intro p
  exact p.distinct

-- Lo transferimos automáticamente a cruces
theorem crossing_property : ∀ c : RationalCrossing 3, c.over_pos ≠ c.under_pos :=
  transfer_to_crossing (by
    intro p
    exact pair_property p
  )

-- O más directamente:
example : ∀ c : RationalCrossing 3, c.over_pos ≠ c.under_pos := by
  intro c
  exact (c⟦⟧ᵃ).distinct
```

### Ejemplo 2: De Topológico a Algebraico

```lean
-- Teorema sobre cruces
theorem crossing_theorem (c : RationalCrossing 3) : 
  modular_ratio c ≠ 0 := by
  -- Prueba topológica
  sorry

-- Transferir a pares
theorem pair_theorem (p : OrderedPair) :
  p.snd - p.fst ≠ 0 :=
  transfer_to_pair (by
    intro c
    have := crossing_theorem c
    simpa [displacement_commutes] using this
  )
```

### Ejemplo 3: Transferencia Universal

```lean
-- Principio general: cualquier predicado se transfiere
theorem universal_example (P : RationalCrossing 3 → Prop) :
  (∀ c, P c) ↔ (∀ p : OrderedPair, P (p⟦⟧ᵗ)) :=
  universal_transfer_principle P
```

---

## 📊 Casos de Uso Comunes

### Caso 1: Trabajar en el Contexto Más Conveniente

```lean
-- Problema: Probar una propiedad sobre configuraciones K₃

theorem k3_property (K : K3Config) : ... := by
  -- Paso 1: Elegir el contexto más conveniente
  -- ¿Propiedad topológica? Usa RationalCrossing
  -- ¿Propiedad algebraica? Usa OrderedPair
  
  -- Paso 2: Trabajar en ese contexto
  have h_algebraic : ∀ p ∈ K.pairs, ... := by
    intro p hp
    -- Prueba algebraica
    ...
  
  -- Paso 3: Si necesitas el otro contexto, transfiere
  have h_topological : ∀ c, ... := by
    apply transfer_to_crossing
    exact h_algebraic
  
  -- Paso 4: Concluir
  ...
```

### Caso 2: Verificar Consistencia entre Definiciones

```lean
-- Asegurar que R1 está definido consistentemente

-- En Basic.lean (topológico)
def has_r1_crossing (c : RationalCrossing n) : Prop := ...

-- En TCN_01 (algebraico)
def has_r1_pair (p : OrderedPair) : Prop := ...

-- Verificar consistencia
theorem r1_consistent : 
  ∀ c : RationalCrossing 3, 
    has_r1_crossing c ↔ has_r1_pair (c⟦⟧ᵃ) := by
  intro c
  -- Si esta prueba falla, las definiciones son inconsistentes
  ...
```

### Caso 3: Extensión con Nuevas Propiedades

```lean
-- Agregar nueva propiedad en un contexto
def new_property_pair (p : OrderedPair) : Prop := ...

-- Obtener automáticamente la versión topológica
def new_property_crossing (c : RationalCrossing 3) : Prop :=
  new_property_pair (c⟦⟧ᵃ)

-- Probar equivalencia
theorem new_property_transfers :
  ∀ c, new_property_crossing c ↔ new_property_pair (c⟦⟧ᵃ) := by
  intro c
  rfl  -- Por definición
```

---

## 🎓 Patrones Avanzados

### Patrón 1: Composición de Isomorfismos

```lean
-- Si tienes múltiples isomorfismos
def iso1 : A ≃ B := ...
def iso2 : B ≃ C := ...

-- Componerlos
def iso_composed : A ≃ C := iso1.trans iso2

-- Con nuestro isomorfismo
def some_map : OrderedPair ≃ OtherType := ...
def full_iso : RationalCrossing 3 ≃ OtherType :=
  crossing_to_pair.trans some_map
```

### Patrón 2: Funtorialidad

```lean
-- El isomorfismo preserva composiciones de funciones
theorem functorial_property 
    {α β : Type*}
    (f : α → RationalCrossing 3)
    (g : RationalCrossing 3 → β) :
  (fun x => g (f x)⟦⟧ᵃ) = (fun x => g (f x)⟦⟧ᵃ) :=
  iso_is_functorial f g
```

### Patrón 3: Transferencia de Relaciones

```lean
-- Transferir no solo predicados, sino relaciones
theorem relation_transfer 
    {R_cross : RationalCrossing 3 → RationalCrossing 3 → Prop}
    {R_pair : OrderedPair → OrderedPair → Prop}
    (h_equiv : ∀ c₁ c₂, R_cross c₁ c₂ ↔ R_pair (c₁⟦⟧ᵃ) (c₂⟦⟧ᵃ))
    (h_pair : ∀ p₁ p₂, R_pair p₁ p₂) :
  ∀ c₁ c₂, R_cross c₁ c₂ :=
  transfer_relation h_equiv h_pair
```

---

## 🔍 Testing y Verificación

### Tests Incluidos

El módulo incluye tests de consistencia:

```lean
-- Test: Biyectividad
example : Function.Bijective crossing_to_pair := ...

-- Test: Inversa correcta
example : pair_to_crossing.toFun ∘ crossing_to_pair.toFun = id := ...

-- Test: Determinismo
example (c : RationalCrossing 3) :
  (c⟦⟧ᵃ)⟦⟧ᵗ = c ∧ ((c⟦⟧ᵃ)⟦⟧ᵗ)⟦⟧ᵃ = c⟦⟧ᵃ := ...
```

### Agregar Tus Propios Tests

```lean
-- Template para tests
example (property_name : String) : ... := by
  -- 1. Crear datos de prueba
  let c : RationalCrossing 3 := ...
  let p : OrderedPair := ...
  
  -- 2. Verificar conversiones
  have h1 : c⟦⟧ᵃ = ... := by ...
  have h2 : p⟦⟧ᵗ = ... := by ...
  
  -- 3. Verificar preservación de propiedades
  have h3 : property_A c ↔ property_B (c⟦⟧ᵃ) := by ...
  
  ...
```

---

## 📐 Extensiones Futuras

### Para K₄ (4 cruces)

```lean
-- Crear versión para K₄
def crossing_to_pair_k4 : RationalCrossing 4 ≃ OrderedPair_K4 where
  toFun c := ⟨c.over_pos, c.under_pos, c.distinct⟩
  invFun p := ⟨p.fst, p.snd, p.distinct⟩
  left_inv _ := rfl
  right_inv _ := rfl

-- Usar el mismo patrón de notación
notation:max c "⟦⟧ᵃ⁴" => crossing_to_pair_k4 c
```

### Generalización a Kₙ

```lean
-- Versión parametrizada
def crossing_to_pair_kn (n : ℕ) [NeZero n] :
    RationalCrossing n ≃ OrderedPair_Kn n where
  toFun c := ⟨c.over_pos, c.under_pos, c.distinct⟩
  invFun p := ⟨p.fst, p.snd, p.distinct⟩
  left_inv _ := rfl
  right_inv _ := rfl
```

### Isomorfismos Adicionales

Potenciales extensiones:
- `K3Config ≃ KnotDiagram 3`
- `MatchingPerfect ≃ ConfigurationSet`
- `ChiralPair ≃ OrientedCrossing`

---

## 🎯 Mejores Prácticas

### DO ✅

1. **Usar en ambos contextos**
   - No favorezca arbitrariamente uno sobre el otro
   - Elija el contexto según la propiedad a probar

2. **Documentar conversiones**
   ```lean
   -- Convertir a algebraico para usar teorema de DME
   let p := c⟦⟧ᵃ
   have h := dme_property p
   ```

3. **Usar tácticas de transferencia**
   - Más robusto que conversiones manuales
   - Automáticamente mantiene coherencia

4. **Verificar preservación**
   ```lean
   -- Siempre verificar que nuevas propiedades se preservan
   theorem new_prop_preserves : ... ↔ ... := ...
   ```

### DON'T ❌

1. **No convertir innecesariamente**
   ```lean
   -- Mal: Conversión sin propósito
   def foo (c : RationalCrossing 3) := (c⟦⟧ᵃ)⟦⟧ᵗ  -- = c
   
   -- Bien: Conversión con propósito
   def foo (c : RationalCrossing 3) := 
     let p := c⟦⟧ᵃ
     compute_dme p  -- Requiere OrderedPair
   ```

2. **No asumir que son "el mismo tipo"**
   ```lean
   -- Mal: Mezclar sin conversión explícita
   -- def bar (c : RationalCrossing 3) (p : OrderedPair) := c = p  -- ERROR
   
   -- Bien: Conversión explícita
   def bar (c : RationalCrossing 3) (p : OrderedPair) := c⟦⟧ᵃ = p
   ```

3. **No duplicar teoremas innecesariamente**
   ```lean
   -- Mal: Probar en ambos lados manualmente
   theorem prop_crossing : ... := by ...
   theorem prop_pair : ... := by ...  -- Duplicado
   
   -- Bien: Probar una vez, transferir
   theorem prop_pair : ... := by ...
   theorem prop_crossing := transfer_to_crossing prop_pair
   ```

---

## 📚 Referencias

### En Este Proyecto

- `Basic.lean`: Definición de `RationalCrossing`
- `TCN_01_Fundamentos.lean`: Definición de `OrderedPair`
- `ESTRATEGIA_UNIFICACION_VS_SEPARACION.md`: Justificación del diseño

### En Mathlib

- `Data.Equiv.Basic`: Teoría de equivalencias
- `Logic.Equiv.Defs`: Definiciones fundamentales
- Ejemplos de múltiples representaciones isomorfas

### Literatura

- HoTT Book: Equivalences as equality
- Category Theory: Isomorphisms as structure-preserving bijections

---

## ⚡ Quick Reference

```lean
-- Importar
import TMENudos.CrossingPairIsomorphism

-- Convertir topológico → algebraico
c⟦⟧ᵃ

-- Convertir algebraico → topológico
p⟦⟧ᵗ

-- Transferir teorema: algebraico → topológico
transfer_to_crossing h_pair

-- Transferir teorema: topológico → algebraico
transfer_to_pair h_crossing

-- Verificar preservación
iso_preserves_first
iso_preserves_second
iso_preserves_displacement

-- Involutividad
iso_roundtrip_crossing
iso_roundtrip_pair
```

---

## 💡 Conclusión

`CrossingPairIsomorphism.lean` es más que código de "pegamento" entre dos tipos. Es la **formalización del insight central de TME**: que topología de nudos y álgebra modular son dos caras de la misma moneda.

Al hacer este isomorfismo explícito:
- ✅ Preservamos riqueza semántica de cada contexto
- ✅ Formalizamos la dualidad topología-álgebra
- ✅ Permitimos trabajo flexible en el contexto más conveniente
- ✅ Garantizamos consistencia mediante verificación formal

**Úsalo libremente** para navegar entre perspectivas según necesites.

---

**Autor**: Análisis TME  
**Fecha**: Diciembre 2025  
**Archivo**: CrossingPairIsomorphism.lean (519 líneas)  
**Estado**: Completo y documentado
